<footer id="fh5co-footer" role="contentinfo">

		<div class="container">
			<div class="col-md-3 col-sm-12 col-sm-push-0 col-xs-12 col-xs-push-0">
				<h3>About Us</h3>
				<p>TECHNO merupakan perusahaan yang bergerak dan memfokuskan diri pada bidang Konsultan IT dan Security.</p>
			</div>
			<div class="col-md-6 col-md-push-1 col-sm-12 col-sm-push-0 col-xs-12 col-xs-push-0">
				<h3>Our Services</h3>
				<ul class="float">
					<li><a href="<?php echo base_url().'portfolio'?>">Web Design</a></li>
					<li><a href="<?php echo base_url().'portfolio'?>">IT Consulting</a></li>
					<li><a href="<?php echo base_url().'portfolio'?>">Software & Program</a></li>
					<li><a href="<?php echo base_url().'portfolio'?>">IT Audit</a></li>
				</ul>
				<ul class="float">
					<li><a href="<?php echo base_url().'portfolio'?>">SEO Service</a></li>
					<li><a href="<?php echo base_url().'portfolio'?>">Hardware & Nerworking</a></li>
					<li><a href="<?php echo base_url().'portfolio'?>">Online Marketing</a></li>
					<li><a href="<?php echo base_url().'portfolio'?>">Graphic Design</a></li>
				</ul>

			</div>

			<div class="col-md-2 col-md-push-1 col-sm-12 col-sm-push-0 col-xs-12 col-xs-push-0">
				<h3>Follow Us</h3>
				<ul class="fh5co-social">
					<li><a href="#"><i class="icon-twitter"></i></a></li>
					<li><a href="#"><i class="icon-facebook"></i></a></li>
					<li><a href="#"><i class="icon-google-plus"></i></a></li>
					<li><a href="#"><i class="icon-instagram"></i></a></li>
				</ul>
			</div>


			<div class="col-md-12 fh5co-copyright text-center">
				<p>&copy; 2020 by <a href="#" target="_blank">Katagonia</a>. All Rights Reserved.</p>
			</div>

		</div>
	</footer>
